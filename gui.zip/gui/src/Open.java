public class Open {
    public static void main(String[] args){
form1 form1=new form1();
form1.setVisible(true);
    }
}
