import javax.swing.*;

public class form1 extends JFrame {
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JButton đăngKíButton;
    private JButton đăngNhậpButton;
    private JPanel panel1;
    public form1(){
    add(panel1);
    setSize(1000,500);
    setTitle("Form login");
}

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}

