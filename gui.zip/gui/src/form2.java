import javax.swing.*;

public class form2 extends JFrame {
    private JButton đăngKíButton;
    private JButton thoátButton;
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JPanel panel2;
    public form2(){
        add(panel2);
        setSize(200,50);
        setTitle("Đăng kí");
    }
}
