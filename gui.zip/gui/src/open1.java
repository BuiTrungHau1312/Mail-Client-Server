public class open1 {
    public static void main(String[] args){
        form2 form2=new form2();
        form2.setVisible(true);
    }
}
